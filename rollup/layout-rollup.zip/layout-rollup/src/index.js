/* eslint-disable no-console */
import { PluginName } from './PluginName.plugin';

// import { CreatePluginNameClass } from './PluginName.plugin.class';

import './style.scss';

// Create three headers
for (let i = 0; i < 3; i += 1) {
  // Create header <h2>
  const $h2 = document.createElement('h2');

  // $h2.classList.add('hide-xs');
  // Add text for header
  // $h2.innerText = `Tag <h2> ${i}`;
  $h2.innerHTML = '<span class="hide-xs">hide-xs 576px</span><span class="hide-sm">hide-sm 768px</span>';
  // Add a heading to the document
  document.body.appendChild($h2);
}

// Init Plugin
const pluginInstances = new PluginName('h2');

// Get Plugin Options
console.log(pluginInstances[0].options);

// Call Destroy Method for first <h2>
pluginInstances[0].destroy();
