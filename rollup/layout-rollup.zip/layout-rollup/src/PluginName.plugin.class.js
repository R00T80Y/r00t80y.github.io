const defaultOptions = {
  // Plugin options here...

  // Plugin Hooks
  init: false,
  destroy: false,
};

class PluginNameClass {
  #$rootElement
  #options

  constructor($rootElement, pluginOptions) {
    console.log('Plugin constructor');

    this.#$rootElement = $rootElement;
    this.#options = pluginOptions;

    this.#$rootElement.addEventListener('click', this.#onPluginClick);
  }

  #onPluginClick(event) {
    let $target = event.target;
    console.log('Click ' + $target.innerText)
  }

  getData() {
    return 'Get Data';
  }
};

class CreatePluginNameClass {
  constructor(element, customOptions) {
    const nodeList = [];
    const instances = [];

    if (element && element instanceof HTMLElement) {
      nodeList.push(element);
    } else if (element && typeof element === 'string') {
      const elementsList = document.querySelectorAll(element);
      for (let i = 0, l = elementsList.length; i < l; i += 1) {
        if (elementsList[i] instanceof HTMLElement) {
          nodeList.push(elementsList[i]);
        }
      }
    } else if (element && element.length) {
      for (let i = 0, l = element.length; i < l; i += 1) {
        if (element[i] instanceof HTMLElement) {
          nodeList.push(element[i]);
        }
      }
    }

    for (let i = 0, l = nodeList.length; i < l; i += 1) {
      instances.push(
        new PluginNameClass(
          nodeList[i],
          {
            ...defaultOptions,
            ...customOptions,
            name: 'PluginName'
          }
        )
      );
    }

    return instances;
  }
};

export {
  CreatePluginNameClass
};
