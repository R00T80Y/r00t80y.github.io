# Модуль container

## Переменные
```
$container-max-width: 1152px !default;
$container-gap: 16px !default;
```

## Как использовать?

### Пример 1:
```
<div class="container-outer">
  <div class="container-inner">
  </div>
</div>
```

### Пример 2: Одним элементом
```
.container-main {
  @include container-outer;
  @include container-inner;
}
```
