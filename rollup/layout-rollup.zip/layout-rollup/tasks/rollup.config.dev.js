import copy from 'rollup-plugin-copy';
import resolve from '@rollup/plugin-node-resolve';
import { babel } from '@rollup/plugin-babel';
import html from '@rollup/plugin-html';
import postcss from 'rollup-plugin-postcss';
import paths from './paths';

const path = require('path');

export default {
  input: `${paths.source}/index.js`,
  output: [{
    file: `${paths.build}/index.umd.js`,
    format: 'umd',
    sourcemap: true,
    name: 'PluginName'
  }],
  plugins: [
    copy({
      targets: [
        { src: `${paths.public}/*`, dest: paths.build }
      ]
    }),
    postcss({
      // use: ['sass'],
      // plugins: ['postcss-combine-media-query'],
      extract: path.resolve(`${paths.build}/styles.css`)
    }),
    babel({
      babelHelpers: 'bundled',
      exclude: 'node_modules/**'
    }),
    html({
      // include: `${paths.source}/**/*.html`
    }),
    resolve()
  ]
};
